# Smart Emergency Vehicle Priority System

Premium hackathon prototype for demonstrating an intelligent emergency-vehicle priority workflow.

## Demo

1. Open `index.html`.
2. Click **Start emergency simulation**.
3. Watch the ambulance move through the simulated city network.
4. Observe authentication, location tracking, junction identification, traffic alert, safe signal transition, priority green, and normal traffic restoration.
5. Use **Pause** and **Reset** during the demo.

## Features

- Premium responsive control-center UI
- Emergency vehicle detection simulation
- Authorized vehicle verification
- Live simulated distance and route
- Three-junction visual network
- Safe RED → YELLOW → GREEN transition
- Traffic-control alert panel
- Live event stream
- Response-time and estimated time-saved metrics
- Simulation controls

## Run locally

No build tools are required.

Open `index.html` directly in Chrome or Edge.

## GitHub Pages

Create a public GitHub repository, upload:
- `index.html`
- `style.css`
- `script.js`
- `README.md`

Then go to:

Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.

GitHub will provide a public Pages URL.

## Important

This is a simulation prototype. It does not control real traffic infrastructure. Real deployment would require authorized integration with traffic-signal controllers, emergency services, secure authentication, communications, safety validation, and applicable regulations.

## Presentation line

“We are not claiming to reinvent the emergency siren. Our prototype demonstrates the coordination layer that connects an authenticated emergency vehicle with upcoming traffic-control points to create a safer, faster priority corridor.”
